require("dotenv").config();
const path = require("path");
const TelegramBot = require("node-telegram-bot-api");

const { FirestoreClient } = require("./lib/firestoreClient");
const {
  createLicense,
  getLicense,
  updateLicense,
  deleteLicense,
  unbindDevice,
  findLicensesByDevice,
  listAllTokens,
} = require("./lib/licenseStore");
const { generateUniqueToken } = require("./lib/tokenGenerator");
const { formatLicenseCard, isValidToken, isValidDeviceId, escapeMd } = require("./lib/format");

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_ID = String(process.env.ADMIN_TELEGRAM_ID || "");
const SERVICE_ACCOUNT_PATH =
  process.env.SERVICE_ACCOUNT_PATH || path.join(__dirname, "serviceAccountKey.json");

if (!TOKEN) {
  console.error("TELEGRAM_BOT_TOKEN belum diisi di .env");
  process.exit(1);
}
if (!ADMIN_ID) {
  console.error("ADMIN_TELEGRAM_ID belum diisi di .env");
  process.exit(1);
}

let firestore;
try {
  firestore = new FirestoreClient(SERVICE_ACCOUNT_PATH);
} catch (err) {
  console.error(err.message);
  process.exit(1);
}

// ── Jaga-jaga: pastikan serviceAccountKey.json ini benar-benar milik
// project Firebase yang SAMA dengan yang dipakai aplikasi Android
// (app/google-services.json), bukan project lain / key dari akun lain.
//
// Kalau ini beda project, bot akan tetap bisa generate lisensi TANPA error
// sama sekali (REST call ke Firestore-nya sukses 200 OK) — cuma dokumennya
// nyasar ke project yang salah, jadi app tidak akan pernah menemukan kode
// itu. Ini persis gejala "bot bilang berhasil tapi kode 'tidak ditemukan'
// di app" yang sebelumnya sulit dilacak karena tidak ada pesan error.
//
// Isi EXPECTED_PROJECT_ID di .env untuk mengaktifkan pengecekan ini (ambil
// dari project_id di app/google-services.json project Android-mu). Kalau
// tidak diisi, pengecekan dilewati (biar tidak memaksa breaking change buat
// yang belum sempat set .env).
const EXPECTED_PROJECT_ID = process.env.EXPECTED_PROJECT_ID;
if (EXPECTED_PROJECT_ID && firestore.projectId !== EXPECTED_PROJECT_ID) {
  console.error(
    `❌ serviceAccountKey.json ini untuk project Firebase "${firestore.projectId}", ` +
      `tapi EXPECTED_PROJECT_ID di .env diisi "${EXPECTED_PROJECT_ID}".\n` +
      `   Lisensi yang dibuat bot ini TIDAK akan terlihat di aplikasi Android kalau project-nya beda.\n` +
      `   Ambil ulang serviceAccountKey.json dari Firebase Console -> project "${EXPECTED_PROJECT_ID}" ` +
      `-> Project Settings -> Service accounts -> Generate new private key.`
  );
  process.exit(1);
}
if (!EXPECTED_PROJECT_ID) {
  console.warn(
    `⚠️  EXPECTED_PROJECT_ID belum diisi di .env — pengecekan project Firestore dilewati.\n` +
      `   Bot ini akan menulis ke project "${firestore.projectId}" (dari serviceAccountKey.json).\n` +
      `   Pastikan ini SAMA PERSIS dengan project_id di app/google-services.json aplikasi Android-mu,\n` +
      `   kalau tidak, lisensi yang dibuat bot tidak akan pernah terbaca di app.`
  );
}

const bot = new TelegramBot(TOKEN, { polling: true });

// ── State percakapan sederhana per chat ──
const sessions = new Map();

function isAdmin(msg) {
  return String(msg.from.id) === ADMIN_ID;
}

function requireAdmin(msg) {
  if (!isAdmin(msg)) {
    bot.sendMessage(msg.chat.id, "⛔ Kamu tidak punya akses ke perintah ini.");
    return false;
  }
  return true;
}

function clearSession(chatId) {
  sessions.delete(chatId);
}

function mainMenuKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "🎫 Generate Lisensi", callback_data: "menu:generate" },
          { text: "🔍 Cek Lisensi", callback_data: "menu:check" },
        ],
        [
          { text: "✏️ Edit Lisensi", callback_data: "menu:edit" },
          { text: "🗑️ Hapus Lisensi", callback_data: "menu:delete" },
        ],
        [
          { text: "📱 Cek Device ID", callback_data: "menu:device" },
          { text: "🔓 Reset Device", callback_data: "menu:unbind" },
        ],
        [{ text: "📋 Daftar Lisensi", callback_data: "menu:list" }],
      ],
    },
  };
}

// ─────────────────────────────────────────────────────────
// /start & /help
// ─────────────────────────────────────────────────────────
bot.onText(/^\/start$/, (msg) => {
  const chatId = msg.chat.id;
  clearSession(chatId);
  const name = escapeMd(msg.from.first_name || "");
  bot.sendMessage(
    chatId,
    `👋 Halo, ${name}\\!\n\n` +
      `Bot manajemen lisensi *AetherX* siap dipakai \\(terhubung ke Firestore\\)\\.\n` +
      `Pilih menu di bawah, atau ketik /help untuk daftar perintah lengkap\\.`,
    { parse_mode: "MarkdownV2", ...mainMenuKeyboard() }
  );
});

bot.onText(/^\/help$/, (msg) => {
  const helpText = [
    "*Perintah tersedia:*",
    "",
    "/generate <hari> [catatan] — Buat lisensi baru. Contoh: /generate 30 Promo Juli",
    "/check <token> — Lihat detail lisensi",
    "/edit <token> — Edit status/expiry/device/catatan lisensi",
    "/delete <token> — Hapus lisensi permanen",
    "/device <deviceId> — Cari lisensi yang terpasang di device ID tsb",
    "/unbind <token> — Lepas device dari lisensi (reset ke status 'unused')",
    "/list — Daftar semua token lisensi",
    "/cancel — Batalkan proses yang sedang berjalan",
    "",
    "Semua perintah admin hanya bisa dipakai oleh admin yang terdaftar\\.",
  ].join("\n");
  bot.sendMessage(msg.chat.id, helpText, { parse_mode: "MarkdownV2" });
});

bot.onText(/^\/cancel$/, (msg) => {
  clearSession(msg.chat.id);
  bot.sendMessage(msg.chat.id, "❎ Proses dibatalkan.", mainMenuKeyboard());
});

// ─────────────────────────────────────────────────────────
// GENERATE LICENSE
// /generate <hari> [catatan]
// ─────────────────────────────────────────────────────────
bot.onText(/^\/generate(?:\s+(.*))?$/, async (msg, match) => {
  if (!requireAdmin(msg)) return;
  const chatId = msg.chat.id;
  const raw = (match[1] || "").trim();

  if (!raw) {
    sessions.set(chatId, { action: "generate", step: "ask_days" });
    return bot.sendMessage(chatId, "Berapa hari masa berlaku lisensi ini? (mis. `30`)", {
      parse_mode: "Markdown",
    });
  }

  const parts = raw.split(/\s+/);
  const days = parseInt(parts[0], 10);
  const note = parts.slice(1).join(" ");

  if (!Number.isFinite(days) || days <= 0) {
    return bot.sendMessage(chatId, "⚠️ Format: /generate <jumlah_hari> [catatan]. Contoh: /generate 30 Promo Juli");
  }

  await doGenerate(chatId, days, note);
});

async function doGenerate(chatId, days, note) {
  try {
    const token = await generateUniqueToken(firestore);
    const license = await createLicense(firestore, { token, days, note });
    await bot.sendMessage(
      chatId,
      `✅ *Lisensi baru berhasil dibuat\\!*\n\n${formatLicenseCard(license)}`,
      { parse_mode: "MarkdownV2" }
    );
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `❌ Gagal generate lisensi: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────
// CHECK LICENSE
// ─────────────────────────────────────────────────────────
bot.onText(/^\/check(?:\s+(.*))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const token = (match[1] || "").trim();

  if (!token) {
    sessions.set(chatId, { action: "check", step: "waiting_token" });
    return bot.sendMessage(chatId, "Kirim token lisensi yang mau dicek (7 karakter):");
  }
  await handleCheck(chatId, token);
});

async function handleCheck(chatId, token) {
  if (!isValidToken(token)) {
    return bot.sendMessage(chatId, "⚠️ Format token tidak valid. Token harus 7 karakter huruf/angka.");
  }
  try {
    const license = await getLicense(firestore, token);
    if (!license) {
      return bot.sendMessage(chatId, `❌ Token \`${token}\` tidak ditemukan.`, { parse_mode: "Markdown" });
    }
    bot.sendMessage(chatId, formatLicenseCard(license), { parse_mode: "MarkdownV2" });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────
// DEVICE ID LOOKUP
// ─────────────────────────────────────────────────────────
bot.onText(/^\/device(?:\s+(.*))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const deviceId = (match[1] || "").trim();

  if (!deviceId) {
    sessions.set(chatId, { action: "device", step: "waiting_device" });
    return bot.sendMessage(chatId, "Kirim Device ID yang mau dicek:");
  }
  await handleDeviceCheck(chatId, deviceId);
});

async function handleDeviceCheck(chatId, deviceId) {
  if (!isValidDeviceId(deviceId)) {
    return bot.sendMessage(chatId, "⚠️ Device ID tidak valid (minimal 4 karakter).");
  }
  try {
    const licenses = await findLicensesByDevice(firestore, deviceId);
    if (licenses.length === 0) {
      return bot.sendMessage(chatId, `📱 Device ID \`${deviceId}\` belum terdaftar di lisensi manapun.`, {
        parse_mode: "Markdown",
      });
    }
    const cards = licenses.map(formatLicenseCard).join("\n\n───\n\n");
    bot.sendMessage(chatId, `📱 Lisensi yang terkait Device ID ini:\n\n${cards}`, { parse_mode: "MarkdownV2" });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────
// UNBIND DEVICE
// ─────────────────────────────────────────────────────────
bot.onText(/^\/unbind(?:\s+(.*))?$/, async (msg, match) => {
  if (!requireAdmin(msg)) return;
  const chatId = msg.chat.id;
  const token = (match[1] || "").trim();

  if (!token) {
    sessions.set(chatId, { action: "unbind", step: "waiting_token" });
    return bot.sendMessage(chatId, "Kirim token lisensi yang device-nya mau direset:");
  }
  await handleUnbind(chatId, token);
});

async function handleUnbind(chatId, token) {
  if (!isValidToken(token)) {
    return bot.sendMessage(chatId, "⚠️ Format token tidak valid.");
  }
  try {
    const license = await getLicense(firestore, token);
    if (!license) {
      return bot.sendMessage(chatId, `❌ Token \`${token}\` tidak ditemukan.`, { parse_mode: "Markdown" });
    }
    await unbindDevice(firestore, token);
    bot.sendMessage(
      chatId,
      `🔓 Device berhasil dilepas dari token \`${token}\`. Status dikembalikan ke 'unused', lisensi bisa dipakai di device baru.`,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────
// DELETE LICENSE
// ─────────────────────────────────────────────────────────
bot.onText(/^\/delete(?:\s+(.*))?$/, async (msg, match) => {
  if (!requireAdmin(msg)) return;
  const chatId = msg.chat.id;
  const token = (match[1] || "").trim();

  if (!token) {
    sessions.set(chatId, { action: "delete", step: "waiting_token" });
    return bot.sendMessage(chatId, "Kirim token lisensi yang mau dihapus:");
  }
  await confirmDelete(chatId, token);
});

async function confirmDelete(chatId, token) {
  if (!isValidToken(token)) {
    return bot.sendMessage(chatId, "⚠️ Format token tidak valid.");
  }
  const license = await getLicense(firestore, token);
  if (!license) {
    return bot.sendMessage(chatId, `❌ Token \`${token}\` tidak ditemukan.`, { parse_mode: "Markdown" });
  }
  sessions.set(chatId, { action: "delete", step: "confirm", data: { token } });
  bot.sendMessage(
    chatId,
    `⚠️ Yakin mau hapus lisensi ini secara permanen?\n\n${formatLicenseCard(license)}`,
    {
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "✅ Ya, hapus", callback_data: `delete_confirm:${token}` },
            { text: "❌ Batal", callback_data: "delete_cancel" },
          ],
        ],
      },
    }
  );
}

// ─────────────────────────────────────────────────────────
// LIST
// ─────────────────────────────────────────────────────────
bot.onText(/^\/list$/, async (msg) => {
  if (!requireAdmin(msg)) return;
  const chatId = msg.chat.id;
  try {
    const tokens = await listAllTokens(firestore);
    if (tokens.length === 0) {
      return bot.sendMessage(chatId, "Belum ada lisensi yang dibuat.");
    }
    const preview = tokens.slice(0, 50);
    const text =
      `📋 *Total ${tokens.length} lisensi*${tokens.length > 50 ? " (menampilkan 50 pertama)" : ""}:\n\n` +
      preview.map((t) => `\`${t}\``).join("\n");
    bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
  }
});

// ─────────────────────────────────────────────────────────
// EDIT LICENSE (conversation flow)
// ─────────────────────────────────────────────────────────
bot.onText(/^\/edit(?:\s+(.*))?$/, async (msg, match) => {
  if (!requireAdmin(msg)) return;
  const chatId = msg.chat.id;
  const token = (match[1] || "").trim();

  if (!token) {
    sessions.set(chatId, { action: "edit", step: "waiting_token" });
    return bot.sendMessage(chatId, "Kirim token lisensi yang mau diedit:");
  }
  await startEditFlow(chatId, token);
});

async function startEditFlow(chatId, token) {
  if (!isValidToken(token)) {
    return bot.sendMessage(chatId, "⚠️ Format token tidak valid.");
  }
  const license = await getLicense(firestore, token);
  if (!license) {
    return bot.sendMessage(chatId, `❌ Token \`${token}\` tidak ditemukan.`, { parse_mode: "Markdown" });
  }
  sessions.set(chatId, { action: "edit", step: "choose_field", data: { token } });
  bot.sendMessage(chatId, `✏️ Edit lisensi \`${token}\`. Pilih field yang mau diubah:`, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Status", callback_data: "edit_field:status" },
          { text: "Expiry (hari)", callback_data: "edit_field:expiresAt" },
        ],
        [
          { text: "Device ID", callback_data: "edit_field:deviceId" },
          { text: "Catatan", callback_data: "edit_field:note" },
        ],
        [{ text: "❌ Batal", callback_data: "edit_cancel" }],
      ],
    },
  });
}

// ─────────────────────────────────────────────────────────
// CALLBACK QUERY HANDLER
// ─────────────────────────────────────────────────────────
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;
  const msg = { chat: { id: chatId }, from: query.from };

  bot.answerCallbackQuery(query.id).catch(() => {});

  if (data.startsWith("menu:")) {
    const key = data.split(":")[1];
    if (key === "generate") {
      if (!requireAdmin(msg)) return;
      sessions.set(chatId, { action: "generate", step: "ask_days" });
      return bot.sendMessage(chatId, "Berapa hari masa berlaku lisensi ini? (mis. `30`)", {
        parse_mode: "Markdown",
      });
    }
    if (key === "check") {
      sessions.set(chatId, { action: "check", step: "waiting_token" });
      return bot.sendMessage(chatId, "Kirim token lisensi yang mau dicek (7 karakter):");
    }
    if (key === "edit") {
      if (!requireAdmin(msg)) return;
      sessions.set(chatId, { action: "edit", step: "waiting_token" });
      return bot.sendMessage(chatId, "Kirim token lisensi yang mau diedit:");
    }
    if (key === "delete") {
      if (!requireAdmin(msg)) return;
      sessions.set(chatId, { action: "delete", step: "waiting_token" });
      return bot.sendMessage(chatId, "Kirim token lisensi yang mau dihapus:");
    }
    if (key === "device") {
      sessions.set(chatId, { action: "device", step: "waiting_device" });
      return bot.sendMessage(chatId, "Kirim Device ID yang mau dicek:");
    }
    if (key === "unbind") {
      if (!requireAdmin(msg)) return;
      sessions.set(chatId, { action: "unbind", step: "waiting_token" });
      return bot.sendMessage(chatId, "Kirim token lisensi yang device-nya mau direset:");
    }
    if (key === "list") {
      if (!requireAdmin(msg)) return;
      const tokens = await listAllTokens(firestore);
      if (tokens.length === 0) return bot.sendMessage(chatId, "Belum ada lisensi yang dibuat.");
      const preview = tokens.slice(0, 50);
      return bot.sendMessage(
        chatId,
        `📋 *Total ${tokens.length} lisensi*:\n\n` + preview.map((t) => `\`${t}\``).join("\n"),
        { parse_mode: "Markdown" }
      );
    }
    return;
  }

  if (data.startsWith("delete_confirm:")) {
    if (!requireAdmin(msg)) return;
    const token = data.split(":")[1];
    try {
      const ok = await deleteLicense(firestore, token);
      clearSession(chatId);
      return bot.sendMessage(
        chatId,
        ok ? `🗑️ Token \`${token}\` berhasil dihapus.` : `❌ Gagal menghapus token \`${token}\`.`,
        { parse_mode: "Markdown" }
      );
    } catch (err) {
      console.error(err);
      return bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }
  if (data === "delete_cancel") {
    clearSession(chatId);
    return bot.sendMessage(chatId, "❎ Penghapusan dibatalkan.");
  }

  if (data.startsWith("edit_field:")) {
    if (!requireAdmin(msg)) return;
    const field = data.split(":")[1];
    const session = sessions.get(chatId);
    if (!session || session.action !== "edit") {
      return bot.sendMessage(chatId, "Sesi edit tidak ditemukan, mulai lagi dengan /edit <token>");
    }
    session.step = "awaiting_value";
    session.data.field = field;
    sessions.set(chatId, session);

    const prompts = {
      status: "Kirim status baru: `unused`, `active`, atau `revoked`",
      expiresAt: "Kirim jumlah hari masa berlaku baru dihitung dari SEKARANG (angka):",
      deviceId: "Kirim Device ID baru untuk dikunci ke lisensi ini, atau `-` untuk mengosongkan (reset ke unused):",
      note: "Kirim catatan baru:",
    };
    return bot.sendMessage(chatId, prompts[field] || "Kirim nilai baru:", { parse_mode: "Markdown" });
  }
  if (data === "edit_cancel") {
    clearSession(chatId);
    return bot.sendMessage(chatId, "❎ Proses edit dibatalkan.");
  }
});

// ─────────────────────────────────────────────────────────
// MESSAGE HANDLER — melanjutkan conversation flow
// ─────────────────────────────────────────────────────────
bot.on("message", async (msg) => {
  if (!msg.text || msg.text.startsWith("/")) return;
  const chatId = msg.chat.id;
  const session = sessions.get(chatId);
  if (!session) return;

  const text = msg.text.trim();

  try {
    if (session.action === "check" && session.step === "waiting_token") {
      clearSession(chatId);
      return handleCheck(chatId, text);
    }

    if (session.action === "device" && session.step === "waiting_device") {
      clearSession(chatId);
      return handleDeviceCheck(chatId, text);
    }

    if (session.action === "unbind" && session.step === "waiting_token") {
      clearSession(chatId);
      return handleUnbind(chatId, text);
    }

    if (session.action === "delete" && session.step === "waiting_token") {
      return confirmDelete(chatId, text);
    }

    if (session.action === "edit" && session.step === "waiting_token") {
      return startEditFlow(chatId, text);
    }

    if (session.action === "edit" && session.step === "awaiting_value") {
      if (!requireAdmin(msg)) return;
      const { token, field } = session.data;
      const updates = {};

      if (field === "status") {
        if (!["unused", "active", "revoked"].includes(text)) {
          return bot.sendMessage(chatId, "⚠️ Status harus salah satu dari: unused, active, revoked");
        }
        updates.status = text;
      } else if (field === "expiresAt") {
        const days = parseInt(text, 10);
        if (!Number.isFinite(days) || days <= 0) {
          return bot.sendMessage(chatId, "⚠️ Masukkan angka hari yang valid, lebih dari 0.");
        }
        updates.expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
      } else if (field === "deviceId") {
        if (text === "-") {
          await unbindDevice(firestore, token);
          clearSession(chatId);
          const updated = await getLicense(firestore, token);
          return bot.sendMessage(chatId, `✅ Device dilepas\\!\n\n${formatLicenseCard(updated)}`, {
            parse_mode: "MarkdownV2",
          });
        }
        if (!isValidDeviceId(text)) {
          return bot.sendMessage(chatId, "⚠️ Device ID tidak valid (minimal 4 karakter).");
        }
        updates.deviceId = text;
        updates.status = "active";
        updates.activatedAt = new Date();
      } else if (field === "note") {
        updates.note = text;
      }

      if (Object.keys(updates).length > 0) {
        await updateLicense(firestore, token, updates);
      }

      clearSession(chatId);
      const updated = await getLicense(firestore, token);
      return bot.sendMessage(chatId, `✅ Lisensi berhasil diupdate\\!\n\n${formatLicenseCard(updated)}`, {
        parse_mode: "MarkdownV2",
      });
    }

    if (session.action === "generate" && session.step === "ask_days") {
      const days = parseInt(text, 10);
      if (!Number.isFinite(days) || days <= 0) {
        return bot.sendMessage(chatId, "⚠️ Masukkan angka hari yang valid, lebih dari 0.");
      }
      session.data = { days };
      session.step = "ask_note";
      sessions.set(chatId, session);
      return bot.sendMessage(chatId, "Catatan untuk lisensi ini? (opsional, kirim `-` untuk kosongkan)", {
        parse_mode: "Markdown",
      });
    }
    if (session.action === "generate" && session.step === "ask_note") {
      const note = text === "-" ? "" : text;
      clearSession(chatId);
      return doGenerate(chatId, session.data.days, note);
    }
  } catch (err) {
    console.error(err);
    clearSession(chatId);
    bot.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
  }
});

bot.on("polling_error", (err) => {
  console.error("Polling error:", err.message);
});

console.log("🤖 Bot AetherX License Manager (Firestore) berjalan (polling mode)...");
